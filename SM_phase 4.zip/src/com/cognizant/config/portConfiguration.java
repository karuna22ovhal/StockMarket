package com.cognizant.config;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;


public class portConfiguration implements EmbeddedServletContainerCustomizer {

 @Override

 public void customize(ConfigurableEmbeddedServletContainer portConfiguration) {
 // TODO Auto-generated method stub
 portConfiguration.setPort(8086);

 

}

}